var matrix = [[0,0,0,0,0],[0,0,1,0,0],[0,0,0,0,0],[0,1,2,0,1],[0,0,2,0,0]];
var packages = [{
"name": " io.spring.initializr.generator.test", "color": " #3182bd"
}
,{
"name": " io.spring.initializr.generator.test.buildsystem.maven", "color": " #6baed6"
}
,{
"name": " io.spring.initializr.generator.test.io", "color": " #9ecae1"
}
,{
"name": " io.spring.initializr.generator.test.project", "color": " #c6dbef"
}
,{
"name": " io.spring.initializr.generator.test.buildsystem.gradle", "color": " #e6550d"
}
];
