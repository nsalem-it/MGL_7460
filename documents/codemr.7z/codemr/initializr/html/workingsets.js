var EQ_workingSetList = [
{name: 'initializr-actuator', path:'initializr-actuator'},
{name: 'initializr-docs', path:'initializr-docs'},
{name: 'initializr-generator', path:'initializr-generator'},
{name: 'initializr-generator-spring', path:'initializr-generator-spring'},
{name: 'initializr-generator-test', path:'initializr-generator-test'},
{name: 'initializr-metadata', path:'initializr-metadata'},
{name: 'initializr-service-sample', path:'initializr-service-sample'},
{name: 'initializr-version-resolver', path:'initializr-version-resolver'},
{name: 'initializr-web', path:'initializr-web'},
];
