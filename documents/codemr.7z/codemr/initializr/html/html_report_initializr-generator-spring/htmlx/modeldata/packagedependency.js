var matrix = [[0,0,0,0,0,0,0,0,0,0,0,0],[0,0,2,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,2,0,0,0,0,0,0],[0,0,0,0,0,1,0,0,0,0,0,2],[0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0],[0,0,2,0,0,0,0,0,0,0,0,8],[0,0,0,0,2,0,0,0,0,0,0,0],[0,0,2,0,0,0,0,0,0,0,0,4],[0,0,0,0,0,1,0,0,0,0,0,4],[0,0,0,0,0,0,0,0,0,0,0,1],[0,0,0,1,0,0,0,0,0,0,0,0]];
var packages = [{
"name": " ", "color": " #3182bd"
}
,{
"name": " io.spring.initializr.generator.spring.code.java", "color": " #6baed6"
}
,{
"name": " io.spring.initializr.generator.spring.code", "color": " #9ecae1"
}
,{
"name": " io.spring.initializr.generator.spring.build.maven", "color": " #c6dbef"
}
,{
"name": " io.spring.initializr.generator.spring.scm.git", "color": " #e6550d"
}
,{
"name": " io.spring.initializr.generator.spring.util", "color": " #fd8d3c"
}
,{
"name": " io.spring.initializr.generator.spring.code.kotlin", "color": " #fdae6b"
}
,{
"name": " io.spring.initializr.generator.spring.documentation", "color": " #fdd0a2"
}
,{
"name": " io.spring.initializr.generator.spring.code.groovy", "color": " #31a354"
}
,{
"name": " io.spring.initializr.generator.spring.build.gradle", "color": " #74c476"
}
,{
"name": " io.spring.initializr.generator.spring.configuration", "color": " #a1d99b"
}
,{
"name": " io.spring.initializr.generator.spring.build", "color": " #c7e9c0"
}
];
