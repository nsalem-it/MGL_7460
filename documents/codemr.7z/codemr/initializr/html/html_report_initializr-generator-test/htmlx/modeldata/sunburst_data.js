function EQ_GET_DATA(){ 
	  var ret = {
"name": " initializr working set: {initializr-generator-test}", "value": "10058", 
"prmetrics":{"5":1,"6":1,"7":1,"8":1,"9":2,"10":1,"11":1}
,
"prmetricvalues":{"5":0,"6":18,"7":0,"8":674,"9":17,"10":5,"11":64}
,
"children": [ {
"name": "io.spring.initializr.generator.test", "value": "140", 
"pmetrics":{"4":1,"12":1,"13":1,"14":1,"3":1,"1":1,"0":1,"6":1,"8":1,"2":1,"15":1,"16":1}
,
"pmetricvalues":{"4":1,"12":1,"13":0,"14":1,"3":1,"1":1,"0":1,"17":0.0,"6":1,"18":0.0,"8":140,"19":1.0,"2":1,"15":0,"16":30}
,
"children": [ {
"name": "InitializrMetadataTestBuilder","key": "dB","value": "140", 
"metrics":{"20":2,"21":1,"22":1,"23":1,"24":2,"25":1,"26":1,"0":3,"27":2,"28":2,"29":2,"30":1,"31":1,"32":3,"33":2,"34":1,"35":1,"36":1,"16":2,"37":1,"4":2,"8":2,"2":2,"3":3,"1":2}
,
"metricvalues":{"20":7,"21":1,"38":2,"22":1,"23":0.0,"24":138,"25":0,"26":1,"0":3,"27":23,"28":97,"29":0.697,"30":0.0,"31":0,"32":0.714,"39":1,"33":6,"34":26,"40":1,"35":2,"36":1,"16":30,"37":0,"4":2,"8":140,"2":2,"3":3,"1":2}
}
]
 }
,{
"name": "io.spring.initializr.generator.test.buildsystem.maven", "value": "158", 
"pmetrics":{"4":1,"12":1,"13":1,"14":1,"3":1,"1":1,"0":1,"6":1,"8":1,"2":1,"15":1,"16":1}
,
"pmetricvalues":{"4":1,"12":1,"13":0,"14":1,"3":1,"1":1,"0":1,"17":0.5,"6":1,"18":0.0,"8":158,"19":0.5,"2":1,"15":1,"16":55}
,
"children": [ {
"name": "MavenBuildAssert","key": "fb","value": "158", 
"metrics":{"20":3,"21":1,"22":1,"23":1,"24":2,"25":1,"26":3,"0":3,"27":2,"28":2,"29":4,"30":1,"31":1,"32":3,"33":1,"34":1,"35":1,"36":2,"16":3,"37":1,"4":2,"8":2,"2":3,"3":3,"1":3}
,
"metricvalues":{"20":11,"21":0,"38":1,"22":1,"23":0.0,"24":156,"25":0,"26":5,"0":3,"27":23,"28":64,"29":0.822,"30":0.0,"31":0,"32":0.745,"39":1,"33":5,"34":31,"40":0,"35":4,"36":6,"16":55,"37":0,"4":2,"8":158,"2":3,"3":3,"1":3}
}
]
 }
,{
"name": "io.spring.initializr.generator.test.io", "value": "82", 
"pmetrics":{"4":1,"12":1,"13":1,"14":1,"3":1,"1":1,"0":1,"6":1,"8":1,"2":1,"15":1,"16":1}
,
"pmetricvalues":{"4":1,"12":3,"13":0,"14":4,"3":1,"1":1,"0":1,"17":0.375,"6":4,"18":0.25,"8":82,"19":0.375,"2":1,"15":5,"16":29}
,
"children": [ {
"name": "TextAssert","key": "hj","value": "5", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":3,"0":3,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":3}
,
"metricvalues":{"20":0,"21":0,"38":1,"22":0,"23":0.0,"24":4,"25":0,"26":5,"0":3,"27":2,"28":2,"29":0.0,"30":0.0,"31":0,"32":0.333,"39":1,"33":0,"34":0,"40":0,"35":0,"36":0,"16":2,"37":0,"4":1,"8":5,"2":1,"3":1,"1":3}
}
,{
"name": "TextTestUtils","key": "hl","value": "11", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":1,"0":1,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":1}
,
"metricvalues":{"20":3,"21":0,"38":3,"22":0,"23":0.0,"24":10,"25":0,"26":1,"0":1,"27":1,"28":9,"29":0.0,"30":0.0,"31":0,"32":0.444,"39":0,"33":0,"34":6,"40":3,"35":2,"36":3,"16":4,"37":0,"4":1,"8":11,"2":1,"3":1,"1":1}
}
,{
"name": "AbstractTextAssert","key": "u","value": "20", 
"metrics":{"20":2,"21":1,"22":1,"23":1,"24":1,"25":2,"26":3,"0":3,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":2,"16":1,"37":1,"4":1,"8":1,"2":2,"3":1,"1":3}
,
"metricvalues":{"20":7,"21":1,"38":4,"22":0,"23":0.0,"24":19,"25":4,"26":4,"0":3,"27":5,"28":19,"29":0.0,"30":0.0,"31":0,"32":0.56,"39":0,"33":1,"34":10,"40":4,"35":0,"36":6,"16":7,"37":0,"4":1,"8":20,"2":2,"3":1,"1":3}
}
,{
"name": "NodeAssert","key": "f4","value": "46", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":2,"0":2,"27":1,"28":1,"29":4,"30":4,"31":1,"32":2,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":2,"1":2}
,
"metricvalues":{"20":5,"21":0,"38":1,"22":2,"23":0.0,"24":42,"25":0,"26":2,"0":2,"27":7,"28":19,"29":0.857,"30":0.833,"31":1,"32":0.62,"39":0,"33":0,"34":12,"40":1,"35":3,"36":5,"16":16,"37":0,"4":1,"8":46,"2":1,"3":2,"1":2}
}
]
 }
,{
"name": "io.spring.initializr.generator.test.project", "value": "264", 
"pmetrics":{"4":2,"12":2,"13":1,"14":2,"3":1,"1":1,"0":2,"6":2,"8":2,"2":2,"15":1,"16":1}
,
"pmetricvalues":{"4":2,"12":8,"13":1,"14":9,"3":1,"1":1,"0":2,"17":0.5,"6":10,"18":0.5,"8":264,"19":1.0,"2":2,"15":0,"16":77}
,
"children": [ {
"name": "AbstractProjectGenerationTester","key": "r","value": "61", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":2,"25":2,"26":1,"0":3,"27":1,"28":1,"29":3,"30":1,"31":1,"32":3,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":2,"8":2,"2":1,"3":3,"1":1}
,
"metricvalues":{"20":3,"21":0,"38":2,"22":3,"23":0.0,"24":55,"25":2,"26":1,"0":3,"27":12,"28":21,"29":0.8,"30":0.083,"31":0,"32":0.793,"39":0,"33":3,"34":13,"40":2,"35":2,"36":0,"16":19,"37":0,"4":2,"8":61,"2":1,"3":3,"1":1}
}
,{
"name": "ProjectGeneratorTester","key": "gB","value": "21", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":2,"0":2,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":2}
,
"metricvalues":{"20":3,"21":0,"38":1,"22":0,"23":0.0,"24":20,"25":0,"26":2,"0":2,"27":5,"28":10,"29":0.0,"30":0.0,"31":0,"32":0.52,"39":1,"33":3,"34":1,"40":0,"35":0,"36":0,"16":5,"37":0,"4":1,"8":21,"2":1,"3":1,"1":2}
}
,{
"name": "JvmModuleAssert","key": "ec","value": "3", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":3,"0":3,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":3}
,
"metricvalues":{"20":1,"21":0,"38":1,"22":0,"23":0.0,"24":2,"25":0,"26":7,"0":3,"27":1,"28":1,"29":0.0,"30":0.0,"31":0,"32":0.0,"39":1,"33":1,"34":0,"40":0,"35":0,"36":0,"16":1,"37":0,"4":1,"8":3,"2":1,"3":1,"1":3}
}
,{
"name": "ProjectAssetTester","key": "gf","value": "42", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":2,"0":2,"27":1,"28":1,"29":1,"30":1,"31":1,"32":2,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":2,"1":2}
,
"metricvalues":{"20":4,"21":0,"38":1,"22":0,"23":0.0,"24":41,"25":0,"26":2,"0":2,"27":7,"28":12,"29":0.0,"30":0.0,"31":0,"32":0.619,"39":1,"33":3,"34":3,"40":0,"35":0,"36":1,"16":8,"37":0,"4":1,"8":42,"2":1,"3":2,"1":2}
}
,{
"name": "AbstractJvmModuleAssert","key": "k","value": "47", 
"metrics":{"20":1,"21":2,"22":1,"23":1,"24":1,"25":1,"26":3,"0":3,"27":1,"28":1,"29":1,"30":3,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":3}
,
"metricvalues":{"20":5,"21":2,"38":2,"22":3,"23":0.0,"24":42,"25":1,"26":6,"0":3,"27":13,"28":24,"29":0.524,"30":0.727,"31":0,"32":0.514,"39":1,"33":3,"34":16,"40":1,"35":1,"36":2,"16":14,"37":0,"4":1,"8":47,"2":1,"3":1,"1":3}
}
,{
"name": "AbstractModuleAssert","key": "p","value": "26", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":3,"0":3,"27":1,"28":1,"29":1,"30":1,"31":1,"32":2,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":2,"1":3}
,
"metricvalues":{"20":5,"21":1,"38":2,"22":0,"23":0.0,"24":24,"25":1,"26":6,"0":3,"27":8,"28":13,"29":0.0,"30":0.0,"31":0,"32":0.656,"39":1,"33":4,"34":5,"40":1,"35":0,"36":1,"16":8,"37":0,"4":1,"8":26,"2":1,"3":2,"1":3}
}
,{
"name": "ProjectStructure","key": "gN","value": "15", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":1,"0":1,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":1}
,
"metricvalues":{"20":1,"21":0,"38":3,"22":1,"23":0.0,"24":13,"25":0,"26":1,"0":1,"27":4,"28":7,"29":0.5,"30":0.0,"31":0,"32":0.5,"39":1,"33":1,"34":4,"40":2,"35":0,"36":0,"16":5,"37":0,"4":1,"8":15,"2":1,"3":1,"1":1}
}
,{
"name": "AbstractProjectAssert","key": "q","value": "46", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":2,"26":3,"0":3,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":3}
,
"metricvalues":{"20":3,"21":1,"38":2,"22":1,"23":0.0,"24":44,"25":2,"26":5,"0":3,"27":10,"28":24,"29":0.476,"30":0.0,"31":0,"32":0.525,"39":0,"33":1,"34":16,"40":2,"35":0,"36":2,"16":15,"37":0,"4":1,"8":46,"2":1,"3":1,"1":3}
}
,{
"name": "ModuleAssert","key": "fX","value": "3", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":3,"0":3,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":3}
,
"metricvalues":{"20":0,"21":0,"38":1,"22":0,"23":0.0,"24":2,"25":0,"26":7,"0":3,"27":1,"28":1,"29":0.0,"30":0.0,"31":0,"32":0.0,"39":1,"33":0,"34":0,"40":0,"35":0,"36":0,"16":1,"37":0,"4":1,"8":3,"2":1,"3":1,"1":3}
}
]
 }
,{
"name": "io.spring.initializr.generator.test.buildsystem.gradle", "value": "30", 
"pmetrics":{"4":1,"12":1,"13":1,"14":1,"3":1,"1":1,"0":1,"6":1,"8":1,"2":1,"15":1,"16":1}
,
"pmetricvalues":{"4":1,"12":2,"13":0,"14":2,"3":1,"1":1,"0":1,"17":0.333,"6":2,"18":0.0,"8":30,"19":0.667,"2":1,"15":1,"16":13}
,
"children": [ {
"name": "GroovyDslGradleBuildAssert","key": "cE","value": "23", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":3,"0":3,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":3}
,
"metricvalues":{"20":2,"21":0,"38":1,"22":0,"23":0.0,"24":22,"25":0,"26":5,"0":3,"27":8,"28":17,"29":0.0,"30":0.0,"31":0,"32":0.333,"39":1,"33":1,"34":6,"40":0,"35":0,"36":1,"16":10,"37":0,"4":1,"8":23,"2":1,"3":1,"1":3}
}
,{
"name": "GroovyDslGradleSettingsAssert","key": "cG","value": "7", 
"metrics":{"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":3,"0":3,"27":1,"28":1,"29":1,"30":1,"31":1,"32":1,"33":1,"34":1,"35":1,"36":1,"16":1,"37":1,"4":1,"8":1,"2":1,"3":1,"1":3}
,
"metricvalues":{"20":1,"21":0,"38":1,"22":0,"23":0.0,"24":6,"25":0,"26":5,"0":3,"27":3,"28":5,"29":0.0,"30":0.0,"31":0,"32":0.0,"39":1,"33":0,"34":3,"40":0,"35":0,"36":1,"16":3,"37":0,"4":1,"8":7,"2":1,"3":1,"1":3}
}
]
 }
]
 }
;
return ret;
}
var EQ_METRIC_MAP = {};
EQ_METRIC_MAP["C3"] =0;
EQ_METRIC_MAP["Complexity"] =1;
EQ_METRIC_MAP["Coupling"] =2;
EQ_METRIC_MAP["Lack of Cohesion"] =3;
EQ_METRIC_MAP["Size"] =4;
EQ_METRIC_MAP["Number of Highly Problematic Classes"] =5;
EQ_METRIC_MAP["Number of Entities"] =6;
EQ_METRIC_MAP["Number of Problematic Classes"] =7;
EQ_METRIC_MAP["Class Lines of Code"] =8;
EQ_METRIC_MAP["Number of External Packages"] =9;
EQ_METRIC_MAP["Number of Packages"] =10;
EQ_METRIC_MAP["Number of External Entities"] =11;
EQ_METRIC_MAP["Efferent Coupling"] =12;
EQ_METRIC_MAP["Number of Interfaces"] =13;
EQ_METRIC_MAP["Number of Classes"] =14;
EQ_METRIC_MAP["Afferent Coupling"] =15;
EQ_METRIC_MAP["Weighted Method Count"] =16;
EQ_METRIC_MAP["Normalized Distance"] =17;
EQ_METRIC_MAP["Abstractness"] =18;
EQ_METRIC_MAP["Instability"] =19;
EQ_METRIC_MAP["Coupling Between Object Classes"] =20;
EQ_METRIC_MAP["Access to Foreign Data"] =21;
EQ_METRIC_MAP["Number of Fields"] =22;
EQ_METRIC_MAP["Specialization Index"] =23;
EQ_METRIC_MAP["Class-Methods Lines of Code"] =24;
EQ_METRIC_MAP["Number of Children"] =25;
EQ_METRIC_MAP["Depth of Inheritance Tree"] =26;
EQ_METRIC_MAP["Number of Methods"] =27;
EQ_METRIC_MAP["Response For a Class"] =28;
EQ_METRIC_MAP["Lack of Tight Class Cohesion"] =29;
EQ_METRIC_MAP["Lack of Cohesion of Methods"] =30;
EQ_METRIC_MAP["Number of Static Fields"] =31;
EQ_METRIC_MAP["Lack of Cohesion Among Methods(1-CAM)"] =32;
EQ_METRIC_MAP["CBO App"] =33;
EQ_METRIC_MAP["Simple Response For a Class"] =34;
EQ_METRIC_MAP["Number of Static Methods"] =35;
EQ_METRIC_MAP["CBO Lib"] =36;
EQ_METRIC_MAP["Number of Overridden Methods"] =37;
EQ_METRIC_MAP["Degree"] =38;
EQ_METRIC_MAP["OutDegree"] =39;
EQ_METRIC_MAP["InDegree"] =40;
var EQ_SELECTED_CLASS_METRIC 		= "C3";
var EQ_SELECTED_PACKAGE_METRIC 	= "C3";
var EQ_SELECTED_PROJECT_METRIC 	= "Class Lines of Code";
var EQ_CLASS_METRIC_INDEX 	= EQ_METRIC_MAP[EQ_SELECTED_CLASS_METRIC];
var EQ_PACKAGE_METRIC_INDEX	= EQ_METRIC_MAP[EQ_SELECTED_PACKAGE_METRIC];
var EQ_PROJECT_METRIC_INDEX 	= EQ_METRIC_MAP[EQ_SELECTED_PROJECT_METRIC];
var EQ_COLOR_OF_LEVELS = ["#1F77B4","#007F24","#62BF18","#FFC800","#FF5B13","#E50000"];
var EQ_CLASS_METRICS = ["C3","Complexity","Coupling","Lack of Cohesion","Size","Class Lines of Code","Weighted Method Count","Coupling Between Object Classes","Access to Foreign Data","Number of Fields","Specialization Index","Class-Methods Lines of Code","Number of Children","Depth of Inheritance Tree","Number of Methods","Response For a Class","Lack of Tight Class Cohesion","Lack of Cohesion of Methods","Number of Static Fields","Lack of Cohesion Among Methods(1-CAM)","CBO App","Simple Response For a Class","Number of Static Methods","CBO Lib","Number of Overridden Methods","Degree","OutDegree","InDegree"];
var EQ_PACKAGE_METRICS = ["C3","Complexity","Coupling","Lack of Cohesion","Size","Number of Entities","Class Lines of Code","Efferent Coupling","Number of Interfaces","Number of Classes","Afferent Coupling","Weighted Method Count","Normalized Distance","Abstractness","Instability"];
var EQ_PROJECT_METRICS = ["Number of Highly Problematic Classes","Number of Entities","Number of Problematic Classes","Class Lines of Code","Number of External Packages","Number of Packages","Number of External Entities"];
function EQ_GET_COLOR(d) {
if(d.metrics)
return EQ_COLOR_OF_LEVELS[d.metrics[EQ_CLASS_METRIC_INDEX]];
if(d.pmetrics)
return EQ_COLOR_OF_LEVELS[d.pmetrics[EQ_PACKAGE_METRIC_INDEX]];
if(d.prmetrics)
return EQ_COLOR_OF_LEVELS[d.prmetrics[EQ_PROJECT_METRIC_INDEX]];
return EQ_COLOR_OF_LEVELS[0];
}
