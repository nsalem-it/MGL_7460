var matrix = [[0,0,0,2,0,2,0,0,0,0,2,0,0,2,0,0,1],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,8,0,0,1,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0],[6,0,0,1,0,1,0,0,0,0,1,0,0,1,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,4,0,10,0,0,3,0,0,0],[0,0,0,0,0,1,0,0,0,0,0,0,0,3,0,0,0],[0,0,0,0,0,8,0,0,1,0,0,0,0,0,0,0,0],[0,0,0,0,0,8,0,0,1,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,1,0,6,0,0,1,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]];
var packages = [{
"name": " io.spring.initializr.generator.project", "color": " #3182bd"
}
,{
"name": " io.spring.initializr.generator.io.template", "color": " #6baed6"
}
,{
"name": " io.spring.initializr.generator.packaging.jar", "color": " #9ecae1"
}
,{
"name": " io.spring.initializr.generator.packaging", "color": " #c6dbef"
}
,{
"name": " io.spring.initializr.generator.language.kotlin", "color": " #e6550d"
}
,{
"name": " io.spring.initializr.generator.language", "color": " #fd8d3c"
}
,{
"name": " io.spring.initializr.generator.packaging.war", "color": " #fdae6b"
}
,{
"name": " io.spring.initializr.generator.condition", "color": " #fdd0a2"
}
,{
"name": " io.spring.initializr.generator.io", "color": " #31a354"
}
,{
"name": " io.spring.initializr.generator.buildsystem.gradle", "color": " #74c476"
}
,{
"name": " io.spring.initializr.generator.buildsystem", "color": " #a1d99b"
}
,{
"name": " io.spring.initializr.generator.language.groovy", "color": " #c7e9c0"
}
,{
"name": " io.spring.initializr.generator.language.java", "color": " #756bb1"
}
,{
"name": " io.spring.initializr.generator.version", "color": " #9e9ac8"
}
,{
"name": " io.spring.initializr.generator.io.text", "color": " #bcbddc"
}
,{
"name": " io.spring.initializr.generator.buildsystem.maven", "color": " #dadaeb"
}
,{
"name": " io.spring.initializr.generator.project.contributor", "color": " #636363"
}
];
