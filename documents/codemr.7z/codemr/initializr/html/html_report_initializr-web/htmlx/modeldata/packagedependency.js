var matrix = [[0,0,0,0,0],[0,0,0,0,0],[1,1,0,3,0],[0,0,0,0,0],[2,0,1,1,0]];
var packages = [{
"name": " io.spring.initializr.web.support", "color": " #3182bd"
}
,{
"name": " io.spring.initializr.web.mapper", "color": " #6baed6"
}
,{
"name": " io.spring.initializr.web.controller", "color": " #9ecae1"
}
,{
"name": " io.spring.initializr.web.project", "color": " #c6dbef"
}
,{
"name": " io.spring.initializr.web.autoconfigure", "color": " #e6550d"
}
];
