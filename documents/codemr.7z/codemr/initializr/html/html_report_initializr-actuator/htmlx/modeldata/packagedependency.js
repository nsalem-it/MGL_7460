var matrix = [[0,0,0],[1,0,1],[0,0,0]];
var packages = [{
"name": " io.spring.initializr.actuate.info", "color": " #3182bd"
}
,{
"name": " io.spring.initializr.actuate.autoconfigure", "color": " #6baed6"
}
,{
"name": " io.spring.initializr.actuate.stat", "color": " #9ecae1"
}
];
